import MowItNow.{LectureFichier, Tondeuses}

object Test_tondeuse extends LectureFichier {

  def main(args: Array[String]): Unit = {

      // Instantiation de la classe Tondeuses pour déplacer chacune des tondeuses présentes dans le fichier d'entrée
      for (i <- 0 to positionLines.length - 1) {
        var mouvementTondeuse = new Tondeuses((positionLines(i).split(" ").toList) (0).toInt, positionLines(i).split(" ").toList(1).toInt, positionLines(i).split(" ").toList(2), commandLines(i).toList)
        var x = mouvementTondeuse.xInitial
        var y = mouvementTondeuse.yInitial
        var direction = mouvementTondeuse.directionTondeuse
        var num_tondeuse = i + 1
        println(s"Tondeuse $num_tondeuse : $x $y $direction")
      }
  }
}



