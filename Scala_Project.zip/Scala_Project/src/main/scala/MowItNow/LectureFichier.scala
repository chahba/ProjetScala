package MowItNow

import scala.io.Source

class LectureFichier {
  //Import du fichier texte contenant les coordonnées initiales de la pelouse, des tondeuses et les commandes
  var lines = Source.fromFile("src/test/scala/Input_Test.txt").getLines.toArray


// Récupération des différentes lignes du fichier d'entrée

  // Les coordonnées de la pelouse sont placées dans une liste
  val limitPelouse = lines(0).toString.replaceAll(" ", "").toList
  val limitX = limitPelouse(0).toInt
  val limitY = limitPelouse(1).toInt
  assert (limitX> 0 && limitY>0, "Les limites doivent être positives")

  // Isolation des coordonnées initiales de l'ensemble des tondeuses
  val positionLines = lines.zipWithIndex.filter {
    case (item, index) => index != 0 && index % 2 != 0
  }.map(_._1)

  // Isolation des commandes à exécuter pour l'ensemble des tondeuses
  val commandLines = lines.zipWithIndex.filter {
    case (item, index) => index != 0 && index % 2 == 0
  }.map(_._1)

}
