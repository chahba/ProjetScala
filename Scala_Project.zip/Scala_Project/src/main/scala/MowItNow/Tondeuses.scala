package MowItNow

class Tondeuses (var x:Int, var y:Int, var direction:String, commande: List[Any]) extends LectureFichier {

  var xInitial = x
  var yInitial = y
  var directionTondeuse = direction
  var ligneCommande = commande


  // Définition de la fonction avancer tout en vérifiant que la tondeuse ne dépasse pas les limites de la pelouse
  def avancer()=  {
    directionTondeuse match{
      case "N" => if (yInitial<limitY) {
        yInitial = yInitial + 1} else {yInitial}
      case "E" => if (xInitial<limitX) {
        xInitial = xInitial + 1} else {xInitial}
      case "S" => if (0<yInitial) {
        yInitial = yInitial - 1}  else{yInitial}
      case "W" => if ( xInitial<limitX) {
        xInitial = xInitial - 1} else{ xInitial}
    }
  }

  // Définition de la fonction tourner à droite
  def tournerDroite ()  {
    directionTondeuse match {
      case "N" => directionTondeuse ="E"
      case "E" => directionTondeuse ="S"
      case "S" => directionTondeuse ="W"
      case "W" => directionTondeuse ="N"
    }
  }

  //Définition de la fonction tourner à gauche
  def tournerGauche () {
    directionTondeuse match {
      case "N" => directionTondeuse ="W"
      case "W" => directionTondeuse ="S"
      case "S" => directionTondeuse ="E"
      case "E" => directionTondeuse ="N"
    }
  }

  this.applicationCommande()

  // On applique les différentes fonctions aux coordonnées initiales de la tondeuse, en fonction de la lettre de commande lu
  def applicationCommande () {
    for ( l <- ligneCommande) {
      l.toString match {
        case "A" => avancer
        case "D" => tournerDroite
        case "G" => tournerGauche
        case _ =>  println("error")
      }
    }
  }
}